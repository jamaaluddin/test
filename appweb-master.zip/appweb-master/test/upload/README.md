Manual testing for all upload sizes

# Run

cd ./test ; appweb -v

# In another terminal
ejs test-sizes.es
