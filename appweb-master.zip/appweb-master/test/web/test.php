<html>
<head>
</head>
<body>
    <?php date_default_timezone_set("America/Los_angeles"); ?>
    <?php phpinfo(); ?>
</body>
</html>
