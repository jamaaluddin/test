/*
    server.c - Stub

    Regenerate when doing a static build via:

        appweb-esp --combine compile
 */

#include "esp.h"

ESP_EXPORT int esp_app_server_combine(HttpRoute *route, MprModule *module) {
    return 0;
}
