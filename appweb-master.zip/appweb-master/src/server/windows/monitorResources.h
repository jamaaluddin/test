//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by appwebMonitor.rc
//
#define MA_MENU_STATUS                  1
#define MA_MENU_DOC                     2
#define MA_MENU_MANAGE                  3
#define MA_MENU_START                   4
#define MA_MENU_STOP                    5
#define MA_MENU_EXIT                    6
#define MA_MENU_ABOUT                   7
#define IDB_GO                          103
#define IDB_STOP                        105
#define IDD_EXIT                        106

#define ID_MBEDTHISAPPWEBMONITOR_ASDFASDF 40001
#define ID_Menu                         40002
#define ID_MBEDTHISAPPWEBMONITOR_APPWEBDOCUMENTATION 40003

#define IDC_EXIT_QUERY                  1000
#define IDC_EXIT_LINE1                  1001
#define IDC_EXIT_LINE3                  1003
#define IDC_EXIT_LINE2                  1003
#define IDC_PIC                         1004
#define IDC_EXIT_LINE4                  1005
#define IDC_EXIT_LINE5                  1006
#define IDC_EXIT_CHECK1                 1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
