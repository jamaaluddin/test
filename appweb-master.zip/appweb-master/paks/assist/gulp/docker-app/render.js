/*
    render.js - Render
 */

import * as spawn from 'child_process'
import * as gulp from 'gulp'
import * as log from 'fancy-log'
import config from 'assist'

function render(cb) {
    cb()
}

export default gulp.series(render)
