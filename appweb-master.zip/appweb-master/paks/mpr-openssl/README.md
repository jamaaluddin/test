mpr-openssl
===

OpenSSL stack interface. This provides the interface between the MPR Socket layer and the OpenSSL stack.

## Installation

    pak install mpr-openssl

## Configuration

    ./configure --with openssl

## Building

    me

## Get Pak

[https://www.embedthis.com/pak/](https://www.embedthis.com/pak/)
