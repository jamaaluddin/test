pcre
---

### Perl Regular Expressions License

[PCRE License - BSD 2 Clause](http://opensource.org/licenses/BSD-2-Clause)
