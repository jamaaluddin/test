exp-less License
===

[MIT](http://opensource.org/licenses/MIT)
